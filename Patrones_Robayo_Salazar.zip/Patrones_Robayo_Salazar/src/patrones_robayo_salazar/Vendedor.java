/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patrones_robayo_salazar;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author SG702-14
 */
public class Vendedor {
    String nombre;
    String direccion;
    String ciudad;
    int edad;
    int identificacion;
    ArrayList<Productos> Productos = new ArrayList<Productos>();
    ArrayList<Productos> ventas = new ArrayList<Productos>();
    public Vendedor(String nombre, String direccion, String ciudad, int edad, int identificacion) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.edad = edad;
        this.identificacion = identificacion;
        
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }

    @Override
    public String toString() {
        return "Vendedor{" + "nombre=" + nombre + ", direccion=" + direccion + ", ciudad=" + ciudad + ", edad=" + edad + ", identificacion=" + identificacion + ", Productos=" + Productos + '}';
    }
    
    public Productos buscarProducto(String nombreP){
        ArrayList<Productos> P = new ArrayList<Productos>();
        P = this.Productos;
        for(Productos v : Productos){
            if(nombreP.equals(v.nombre)){
                System.out.println("-----Encontrado-----");
                System.out.println("Nombre producto: " + v.getNombre());
                System.out.println("Categoria producto: " + v.getCategoria());
                System.out.println("Cantidad disponibles: " + v.getCantidad());
                return v;
            }
        }
        return null;
    }
    public void añadirProducto(String referencia, String nombreP,String categoria, String descripcion, int precio, int cantidad){
                        Productos nuevoProducto = new Productos(referencia, nombreP, categoria, descripcion, precio, cantidad, this.nombre);
                        Productos.add(nuevoProducto);
                        System.out.println("Producto agregado correctamente");
                        
    }
    public boolean eliminarProducto(String nombrePtemp){
        Scanner in = new Scanner(System.in);
    for(int i = 0; i < Productos.size(); i++){
                            if(nombrePtemp.equals(Productos.get(i).getNombre())){
                                System.out.println("Seguro que desea eliminar el articulo de la tienda?\n"
                                        + "1. si\n"
                                        + "2. no");
                                int eliminar = in.nextInt();
                                in.nextLine();
                                switch(eliminar){
                                    case 1:
                                        Productos.remove(i);
                                        System.out.println("Producto eliminado correctamente");
                                        return true;
                                       
                                    case 2:
                                        System.out.println("El producto no ha sido eliminado");
                                        return false;
                                     
                                }
                            }
                        }
        return false;
    }
    public boolean actualizarCantidadProducto(String nombrePactualizar){
        Scanner in = new Scanner(System.in);
        for(int i = 0; i < Productos.size(); i++){
                            if(nombrePactualizar.equals(Productos.get(i).getNombre())){
                                System.out.println("Ingrese la nueva cantidad disponible del producto");
                                int nuevaCant = in.nextInt();
                                if(nuevaCant > 0){
                                Productos.get(i).setCantidad(nuevaCant);
                                return true;
                                }
                                else{
                                    System.out.println("no se puede agregar una cantidad de 0");
                                    return false;
                                }
                            }
                        }
        return false;
    }
    public void productoVendido(ArrayList<Productos> carrito){
        for(Productos venta : carrito){
            for(int i = 0; i < Productos.size(); i++){
                if(venta.getNombre().equals(Productos.get(i).getNombre())){
                    Productos.get(i).setCantidad(Productos.get(i).getCantidad()-1);
                    ventas.add(venta);
                }
            }
        }
    }
    public void imprimirVentas(){
        System.out.println("Estos son todos los productos que se han vendido");
        int i = 1;
        for(Productos p : ventas){
            System.out.println((i++) +". " +  p.getNombre());
        }
    }
    
    public void verEstadisticas(){
        System.out.println("------------------------------------------------------------");
        System.out.println("Usted ha vendido un total de " + ventas.size() + " productos");
        int totalVentas = 0;
        //Sumar el valor total de los productos vendidos
        for(int i = 0; i<ventas.size();i++){
            totalVentas+= ventas.get(i).getPrecio();
        }
        System.out.println("Estos tienen un valor total de $" + totalVentas );
    }
    
}
