/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patrones_robayo_salazar;

import java.util.ArrayList;
import java.util.Scanner;
import sun.util.resources.cldr.rwk.CalendarData_rwk_TZ;


/**
 *
 * @author SG702-14
 */
public class Cliente {
    String nombre;
    String direccion;
    String ciudad;
    int edad;
    int identificacion;
    ArrayList<Productos> Carrito;

    public Cliente(String nombre, String direccion, String ciudad, int edad, int identificacion, ArrayList<Productos> Carrito) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.edad = edad;
        this.identificacion = identificacion;
        this.Carrito = Carrito;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }
    
    public void llenarCarrito(Productos p, int cantidad){
    for(int i = 0; i<cantidad; i++){
        Carrito.add(p);
        }
        System.out.println("Producto añadido correctamente");
    }
    
    public void verCarrito(){
        for(int i = 0; i < Carrito.size(); i++){
                            System.out.println(Carrito.get(i).toString());
                                        }
    }
    public void vaciarCarrito(){
            do{
            for(int i = 0; i < Carrito.size();i++){
                Carrito.remove(i);
            }
            }while(!Carrito.isEmpty());
            System.out.println("Carrito vaciado correctamente");
    }
    
    public void comprarCarrito(){
        Scanner in = new Scanner(System.in);
    int totalCompra = 0;
                        if(Carrito.isEmpty()){
                            System.out.println("el carrito de compras está vacío");
                        }
                        else{
                        for(int i = 0; i < Carrito.size(); i++){
                            totalCompra += Carrito.get(i).getPrecio();
                                        }
                            System.out.println("El valor total a pagar por los productos añadidos es de " + totalCompra);
                            System.out.println("Desea comprar ahora?\n"
                                    + "1. si\n"
                                    + "2. no");
                            int opcionComprar = in.nextInt();
                            in.nextLine();
                            switch(opcionComprar){
                                case 1:
                                    do{
                                    System.out.println("Escoja el medio de pago\n"
                                            + "1. tarjeta credito\n"
                                            + "2. tarjeta debito\n"
                                            + "3. efectivo\n");
                                    opcionComprar = in.nextInt();
                                    }while(opcionComprar < 1 || opcionComprar > 3);
                                        switch(opcionComprar){
                                            case 1:
                                                int cuotas = 0;
                                                System.out.println("ingrese nombre titular tarjeta credito");
                                                String titularC = in.nextLine();
                                                System.out.println("ingrese numero tarjeta");
                                                int numeroTarjeta = in.nextInt();
                                                System.out.println("codigo tarjeta");
                                                int codigo = in.nextInt();
                                                do{
                                                System.out.println("a cuantas cuotas desea adquirir el producto?");
                                                cuotas = in.nextInt();
                                                }while(cuotas < 1);
                                                System.out.println("Compra realizada exitosamente");
                                                System.out.println("Su compra ha quedado con un total de " + cuotas + " cuotas mensuales con un valor de " + (totalCompra/cuotas) + " cada una");
                                                System.out.println("Compra realizada exitosamente por un valor de  " + totalCompra);
                                                System.out.println("Compra realizada a nombre de "+ titularC + "\n"
                                                        + "con un numero de tarjeta " + numeroTarjeta);
                                                for(int i = 0; i < Carrito.size(); i++){
                                                    Carrito.remove(i);
                                                }
                                                break;
                                            case 2:
                                                System.out.println("ingrese nombre titular tarjeta debito");
                                                String titularD = in.nextLine();
                                                System.out.println("ingrese numero tarjeta");
                                                int numeroTarjetaD = in.nextInt();
                                                System.out.println("codigo tarjeta");
                                                int codigoD = in.nextInt();
                                                System.out.println("Compra realizada exitosamente por un valor de  " + totalCompra);
                                                System.out.println("Compra realizada a nombre de "+ titularD + "\n"
                                                        + "con un numero de tarjeta " + numeroTarjetaD);
                                                for(int i = 0; i < Carrito.size(); i++){
                                                    Carrito.remove(i);
                                                }
                                                break;
                                            case 3:
                                                System.out.println("con cuanto dinero va a pagar los articulos?");
                                                int efectivo = in.nextInt();
                                                if(efectivo < totalCompra){
                                                    do{
                                                    System.out.println("El dinero ingresado no es suficiente para pagar el total");
                                                    System.out.println("ingrese una nueva cantidad de dinero en efectivo");
                                                    efectivo = in.nextInt();
                                                    }while(efectivo < totalCompra);
                                                }
                                                if(efectivo >= totalCompra){
                                                    System.out.println("Compra realizada exitosamente");
                                                    System.out.println("Su cambio en efectivo por la compra es de " + (efectivo - totalCompra));
                                                }
                                                for(int i = 0; i < Carrito.size(); i++){
                                                    Carrito.remove(i);
                                                }
                                                break;
                                        }
                            }
                }
    }
    
}
