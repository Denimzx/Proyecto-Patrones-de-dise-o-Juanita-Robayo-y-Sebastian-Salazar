/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patrones_robayo_salazar;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Patrones_Robayo_Salazar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Cliente> Ccliente = new ArrayList<>();
        ArrayList<Vendedor> Cvendedor = new ArrayList<>();
        Scanner in = new Scanner(System.in);
        int opcion;
        do{
        System.out.println("Bienvenido a la tienda virtual UPC");
        System.out.println("Qué acción desea realizar\n"
                + "1. crear cuenta\n"
                + "2. ingresar como cliente\n"
                + "3. ingresar como vendedor\n"
                + "4. salir");
        opcion = in.nextInt();
        in.nextLine();
        switch(opcion){
            case 1:
                System.out.println("crear cuenta de\n"
                        + "1. vendedor\n"
                        + "2. cliente\n"
                        + "3. salir");
                int opcion3 = in.nextInt();
                
                switch(opcion3){
                    case 1:
                        in.nextLine();
                        System.out.println("Crear cuenta vendedor: ");
                        System.out.println("nombre vendedor: ");
                        String nombreV = in.nextLine();
                        System.out.println("direccion vendedor");
                        String direccionV = in.nextLine();
                        System.out.println("ciudad vendedor");
                        String ciudadV = in.nextLine();
                        System.out.println("edad");
                        int edadV = in.nextInt();
                        System.out.println("Identificación");
                        int idV = in.nextInt();
                        ArrayList<Productos> ProductosV = new ArrayList<>();
                        Cvendedor.add(new Vendedor(nombreV, direccionV, ciudadV, edadV, idV));
                        System.out.println("Se ha creado un vendedor exitosamente");
                        
                        break;
                    case 2:
                        in.nextLine();
                        System.out.println("Crear cuenta cliente: ");
                        System.out.println("nombre cliente: ");
                        String nombreC = in.nextLine();
                        System.out.println("direccion cliente");
                        String direccionC = in.nextLine();
                        System.out.println("ciudad cliente");
                        String ciudadC = in.nextLine();
                        System.out.println("edad");
                        int edadC = in.nextInt();
                        System.out.println("Identificación");
                        int idC = in.nextInt();
                        ArrayList<Productos> Carrito = new ArrayList<>();
                        Ccliente.add(new Cliente(nombreC, direccionC, ciudadC, edadC, idC, Carrito));
                        System.out.println("Se ha creado un cliente exitosamente");
                        break;
                    case 3:
                        System.out.println("Devolviendo menú");
                        break;         
                }
                break;
                
            case 2:
                System.out.println("Ingrese su identificación: ");
                int idTemp = in.nextInt();
                int index = -1;
                for(int i =0; i<Ccliente.size();i++){
                    if(idTemp == Ccliente.get(i).getIdentificacion()){
                        System.out.println("Bienvenido " + Ccliente.get(i).getNombre());
                        index = i;
                        break;
                    }
                }if(index == -1){
                    System.out.println("Usuario inexistente");
                    break;
                }
                int opcionC = -1;
                do{
                System.out.println("Qué desea hacer:\n"
                        + "1. Buscar producto\n"
                        + "2. Ver carrito de compras\n"
                        + "3. Vaciar carrito de compras\n"
                        + "4. Comprar lo que hay en el carrito\n"
                        + "5. salir");
                opcionC = in.nextInt();
                in.nextLine();
                switch(opcionC){
                    case 1:
                        System.out.println("Ingrese el nombre del Producto");
                        String nombreP = in.nextLine();
                        Productos Ptemp = null;
                        for(Vendedor v : Cvendedor){
                            Ptemp = v.buscarProducto(nombreP);
                            if(Ptemp != null){
                                break;
                            }
                        }
                        if(Ptemp == null){
                            System.out.println("Producto no encontrado");
                            break;
                        }
                        System.out.println("1. Añadir al carrito\n"
                                + "2. ver más\n"
                                + "3. salir");
                        int opcionP = in.nextInt();
                        in.nextLine();
                                switch(opcionP){
                                    case 1:
                                        System.out.println("Cuántos desea añadir al carrito de compras?");
                                        int cantidad = in.nextInt();
                                        if(Ptemp.getCantidad() < cantidad){
                                            System.out.println("Cantidad no disponible");
                                        }
                                        else{
                                        Ccliente.get(index).llenarCarrito(Ptemp, cantidad);
                                        }
                                        break;
                                    case 2:
                                            System.out.println(Ptemp.toString());
                                        break;
                                    case 3:
                                        break;
                                        
                                }
                
                        break;
                    case 2:
                        for(int i = 0; i < Ccliente.get(index).Carrito.size(); i++){
                            System.out.println(Ccliente.get(index).Carrito.get(i).toString());
                                        }
                        break;
                    case 3:
                        if(Ccliente.get(index).Carrito.isEmpty()){
                            System.out.println("El carrito de compras ya esta vacio");
                        }else{
                        Ccliente.get(index).vaciarCarrito();
                        }
                        break;
                    case 4:
                        int totalCompra = 0;
                        if(Ccliente.get(index).Carrito.isEmpty()){
                            System.out.println("el carrito de compras está vacío");
                        }
                        else{
                        for(int i = 0; i < Ccliente.get(index).Carrito.size(); i++){
                            totalCompra += Ccliente.get(index).Carrito.get(i).getPrecio();
                                        }
                            System.out.println("El valor total a pagar por los productos añadidos es de " + totalCompra);
                            System.out.println("Desea comprar ahora?\n"
                                    + "1. si\n"
                                    + "2. no");
                            int opcionComprar = in.nextInt();
                            in.nextLine();
                            switch(opcionComprar){
                                case 1:
                                    do{
                                    System.out.println("Escoja el medio de pago\n"
                                            + "1. tarjeta credito\n"
                                            + "2. tarjeta debito\n"
                                            + "3. efectivo\n");
                                    opcionComprar = in.nextInt();
                                    }while(opcionComprar < 1 || opcionComprar > 3);
                                        switch(opcionComprar){
                                            case 1:
                                                int cuotas = 0;
                                                System.out.println("ingrese nombre titular tarjeta credito");
                                                String titularC = in.nextLine();
                                                System.out.println("ingrese numero tarjeta");
                                                int numeroTarjeta = in.nextInt();
                                                System.out.println("codigo tarjeta");
                                                int codigo = in.nextInt();
                                                do{
                                                System.out.println("a cuantas cuotas desea adquirir el producto?");
                                                cuotas = in.nextInt();
                                                }while(cuotas < 1);
                                                System.out.println("Compra realizada exitosamente");
                                                System.out.println("Su compra ha quedado con un total de " + cuotas + " cuotas mensuales con un valor de " + (totalCompra/cuotas) + " cada una");
                                                System.out.println("Compra realizada exitosamente por un valor de  " + totalCompra);
                                                System.out.println("Compra realizada a nombre de "+ titularC + "\n"
                                                        + "con un numero de tarjeta " + numeroTarjeta);
                                                for(Vendedor v: Cvendedor){
                                                    v.productoVendido(Ccliente.get(index).Carrito);
                                                }
                                                Ccliente.get(index).vaciarCarrito();
                                                break;
                                            case 2:
                                                System.out.println("ingrese nombre titular tarjeta debito");
                                                String titularD = in.nextLine();
                                                System.out.println("ingrese numero tarjeta");
                                                int numeroTarjetaD = in.nextInt();
                                                System.out.println("codigo tarjeta");
                                                int codigoD = in.nextInt();
                                                System.out.println("Compra realizada exitosamente por un valor de  " + totalCompra);
                                                System.out.println("Compra realizada a nombre de "+ titularD + "\n"
                                                        + "con un numero de tarjeta " + numeroTarjetaD);
                                                for(Vendedor v: Cvendedor){
                                                    v.productoVendido(Ccliente.get(index).Carrito);
                                                }
                                                Ccliente.get(index).vaciarCarrito();
                                                break;
                                            case 3:
                                                System.out.println("con cuanto dinero va a pagar los articulos?");
                                                int efectivo = in.nextInt();
                                                if(efectivo < totalCompra){
                                                    do{
                                                    System.out.println("El dinero ingresado no es suficiente para pagar el total");
                                                    System.out.println("ingrese una nueva cantidad de dinero en efectivo");
                                                    efectivo = in.nextInt();
                                                    }while(efectivo < totalCompra);
                                                }
                                                if(efectivo >= totalCompra){
                                                    System.out.println("Compra realizada exitosamente");
                                                    System.out.println("Su cambio en efectivo por la compra es de " + (efectivo - totalCompra));
                                                }
                                                for(Vendedor v: Cvendedor){
                                                    v.productoVendido(Ccliente.get(index).Carrito);
                                                }
                                                Ccliente.get(index).vaciarCarrito();
                                                break;
                                        }
                                    
                                    break;
                                case 2:
                                    System.out.println("Retrocediendo al menú");
                                    break;
                                case 3:
                                    break;
                            }
                        }
                        break;
                        
                }
                }while(opcionC != 5);
                        
                break;
            case 3:
                System.out.println("Ingrese su identificación: ");
                int idTempV = in.nextInt();
                int indexV = -1;
                for(int i =0; i<Cvendedor.size();i++){
                    if(idTempV == Cvendedor.get(i).getIdentificacion()){
                        System.out.println("Bienvenido " + Cvendedor.get(i).getNombre());
                        indexV = i;
                        break;
                    }
                }if(indexV == -1){
                    System.out.println("Usuario inexistente");
                    break;
                }
                int opcionV = -1;
                do{
                System.out.println("Qué desea hacer:\n"
                        + "1. Agregar productos\n"
                        + "2. Eliminar productos\n"
                        + "3. Actualizar cantidad de productos\n"
                        + "4. Ver estadisticas de ventas\n"
                        + "5. ver todos los productos vendidos\n"
                        + "6. salir");
                opcionV = in.nextInt();
                in.nextLine();
                switch(opcionV){
                    case 1:
                        System.out.println("Ingrese los datos del producto:\n"
                                + "referencia:  ");
                        String referencia = in.nextLine();
                        System.out.println("nombre producto");
                        String nombreP = in.nextLine();
                        System.out.println("Categoria ");
                        String categoria = in.nextLine();
                        System.out.println("Descripcion ");
                        String descripcion = in.nextLine();
                        System.out.println("Precio");
                        int precio = in.nextInt();
                        System.out.println("Cantidad");
                        int cantidad = in.nextInt();
                        if(cantidad <= 0){
                            System.out.println("no se pueden agregar productos sin Stock");
                        }
                        else{
                        Cvendedor.get(indexV).añadirProducto(referencia, nombreP, categoria, descripcion, precio, cantidad);
                        }
                        break;
                    case 2:
                        System.out.println("Ingrese el nombre del producto que desea eliminar: ");
                        String nombrePtemp = in.nextLine();
                        if(!Cvendedor.get(indexV).eliminarProducto(nombrePtemp)){
                            System.out.println("Producto no eliminado");
                        }
                        break;
                    case 3:
                        System.out.println("Ingrese el nombre del producto que desea actualizar: ");
                        String nombrePactualizar = in.nextLine();
                        if(!Cvendedor.get(indexV).actualizarCantidadProducto(nombrePactualizar)){
                            System.out.println("Producto no encontrado");
                        }
                        break;
                    case 4:
                        Cvendedor.get(indexV).verEstadisticas();
                        break;
                    case 5:
                        Cvendedor.get(indexV).imprimirVentas();
                        break;
                    case 6:
                        break;
                        
                }
                }while(opcionV != 6);
                    
                break;
            case 4:
                System.out.println("Gracias por confiar en nosotros");
                System.exit(0);
                break;
            default:
                 System.out.println("");
                break;
        }
        }while(true);
        
    }
    
}
