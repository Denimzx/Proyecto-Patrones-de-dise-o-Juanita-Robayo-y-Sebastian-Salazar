/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patrones_robayo_salazar;

/**
 *
 * @author SG702-14
 */
public class Productos {
    String referencia;
    String nombre;
    String categoria;
    String descripcion;
    int precio;
    int cantidad;
    String vendedor;

    public Productos(String referencia, String nombre, String categoria, String descripcion, int precio, int cantidad, String vendedor) {
        this.referencia = referencia;
        this.nombre = nombre;
        this.categoria = categoria;
        this.descripcion = descripcion;
        this.precio = precio;
        this.cantidad = cantidad;
        this.vendedor = vendedor;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Producto" + "referencia: " + referencia + " \n nombre: " + nombre + "\n categoria: " + categoria + "\n descripcion: " + descripcion + "\n precio: " + precio + "\n vendedor: " + vendedor ;
    }
    
}
